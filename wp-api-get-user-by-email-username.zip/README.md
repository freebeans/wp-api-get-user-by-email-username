# WP API Get User by Email/Username

A [WP-API](http://wp-api.org/) extension that allows get user by username and email

* `/wp-json/getuser/v1/users/user/<username>`
* `/wp-json/getuser/v1/users/email/<email>`

## Installation
Download plugin, upload from Worpress plugin panel setting and install.